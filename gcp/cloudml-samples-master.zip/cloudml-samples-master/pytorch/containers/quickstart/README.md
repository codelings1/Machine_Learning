# Training with Custom Containers
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)

AI Platform [has added](https://cloud.google.com/ml-engine/docs/release-notes#february_7_2019) support for training models using user provided docker containers. 

See the [custom containers documentation](https://cloud.google.com/ml-engine/docs/custom-containers) for more information.
