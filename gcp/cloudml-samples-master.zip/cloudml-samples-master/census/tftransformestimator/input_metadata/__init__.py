"""Init module for input_metadata"""

# pylint: disable=wildcard-import
from input_metadata import *
# pylint: enable=wildcard-import
