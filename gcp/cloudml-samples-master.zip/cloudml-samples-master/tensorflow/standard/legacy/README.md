# Legacy samples

This samples are kept as part of our commitment to show you
code that run in previous versions of TensorFlow.
We invite the community to migrate it to newer versions if needed.