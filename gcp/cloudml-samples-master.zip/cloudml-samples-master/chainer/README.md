# Chainer Samples

## Model Training with Containers on Cloud ML Engine
* [Chainer: Deep Neural Network](containers/quickstart) - How to train a Chainer model on ML Engine using a custom container with a image dataset, mnist, to classify handwritten digits.
