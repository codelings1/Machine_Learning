# Training with Custom Containers
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)

Cloud Machine Learning Engine recently added support for training models using user provided docker containers. 
