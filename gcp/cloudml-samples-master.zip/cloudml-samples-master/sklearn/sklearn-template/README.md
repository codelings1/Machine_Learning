# Scikit-learn trainer template for AI Platform

## Overview

This contains a code template for implementing a scikit-learn model trainer on AI Platform.
Usage examples are also included.

## Directories

1. [examples](examples): Examples using template 
2. [template](template): Machine Learning pipeline template using scikit-learn

