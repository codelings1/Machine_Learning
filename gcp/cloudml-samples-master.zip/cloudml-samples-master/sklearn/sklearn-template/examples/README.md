# Scikit-learn trainer examples using template for AI Platform
